# thingHMBOMPlugin

鸿蒙构建扩展插件，类似 Maven 的 BOM（Bill of Materials），用于统一管理项目的组件版本依赖。

## 功能

1. **版本覆盖（Overrides）** - 从 `sdk-requirements.json` 读取版本定义，强制统一项目中所有组件的版本
2. **依赖注入（Dependencies）** - 将 `thing-biz-components.json` 中的组件自动添加到 HAP 依赖
3. **构建保障（RuntimeOnly）** - 将业务组件添加到 runtimeOnly，确保构建时一定存在

## 使用方法

### 1. 在 HAP 模块的 `hvigorfile.ts` 中引入插件

```typescript
import { thingBOMPlugin } from '@tuya-harmony/thingHMBOMPlugin';
import { hapTasks } from '@ohos/hvigor-ohos-plugin';

export default {
    system: hapTasks,
    plugins: [
        thingBOMPlugin()
    ]
}
```

### 2. 在 HAP 模块目录创建配置文件

#### thing-biz-components.json（业务组件列表）

```json
{
    "components": {
        "@thingsmart/thingrouter": "1.0.0",
        "@thingsmart/device": "1.1.73",
        "@thingsmart/home": "1.2.21"
    }
}
```

#### sdk-requirements.json（全局版本定义）

```json
{
    "tag": "main",
    "versions": {
        "@thingsmart/thingrouter": "1.0.0",
        "@thingsmart/device": "1.1.73",
        "@thingsmart/home": "1.2.21",
        "@thingsmart/security": "2.0.12"
    }
}
```

## 版本优先级

当同一组件在两个配置文件中版本不一致时，以 `sdk-requirements.json` 为准。
